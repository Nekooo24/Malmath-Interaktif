var currentQuestion = 0;
var score = 0;
var selectedQuestions = [];
var totalQuestions = 10;
var quizTimer;
var timeLeft;
var difficultyTimes = {
    'mudah': 60,
    'sedang': 180,
    'sulit': 300
};

function showPage(pageId) {
    const pages = document.getElementsByClassName('page');
    const body = document.getElementsByTagName('body')[0];
    const container = document.getElementsByClassName('container')[0];

    Array.from(pages).forEach(page => page.classList.remove('active'));

    document.getElementById(pageId).classList.add('active');

    const materiClasses = ['materi-pertambahan', 'materi-pengurangan', 'materi-perkalian', 'materi-pembagian'];
    const videoClasses = ['materi-video-pertambahan', 'materi-video-pengurangan', 'materi-video-perkalian', 'materi-video-pembagian'];
    const quizClasses = ['quiz-page']
    if (materiClasses.includes(pageId)) {
        body.classList.add('body-materi-pertambahan');
        container.classList.add('materi-specific');
    } else if (videoClasses.includes(pageId)) {
        body.classList.add('body-video-specific');
        container.classList.add('video-specific');
    } else if (quizClasses.includes(pageId)) {
        body.classList.add('quiz-specific');
        container.classList.add('quiz-container-specific');
    } else {
        body.classList.remove('body-materi-pertambahan', 'body-video-specific');
        container.classList.remove('materi-specific', 'video-specific');
    }
}




function setupQuiz(subject, difficulty) {
    selectedQuestions = generateQuestions(subject, difficulty, totalQuestions);
    timeLeft = difficultyTimes[difficulty];
    document.getElementById('quiz-title').innerText = 'Soal ' + subject + ' ' + difficulty;
    document.getElementById('question-text').innerText = "Soal Akan Tampil Di Sini Setelah Anda Memulai.";
    document.getElementById('timer').innerText = formatTime(timeLeft);
    showPage('quiz-page');
    document.getElementById('start-button').style.display = 'block';
    document.getElementById('back-button').style.display = 'block';
    document.getElementById('end-button').style.display = 'none';
    document.getElementById('answer-buttons').innerHTML = '';

    document.getElementById('start-button').className = 'main-button ' + difficulty;
}


function startQuiz() {
    document.getElementById('start-button').style.display = 'none';
    document.getElementById('back-button').style.display = 'none';
    document.getElementById('end-button').style.display = 'block';
    displayQuestion(selectedQuestions[currentQuestion]);
    startTimer();
}

function startTimer() {
    quizTimer = setInterval(function () {
        timeLeft--;
        document.getElementById('timer').innerText = formatTime(timeLeft);
        if (timeLeft <= 0) {
            endQuiz();
        }
    }, 1000);
}

function endQuiz() {
    clearInterval(quizTimer);
    showFinalScore();
}

function formatTime(seconds) {
    var minutes = Math.floor(seconds / 60);
    var seconds = seconds % 60;
    return minutes.toString().padStart(2, '0') + ':' + seconds.toString().padStart(2, '0');
}

function generateQuestions(subject, difficulty, numQuestions) {
    var questions = [];
    for (var i = 0; i < numQuestions; i++) {
        var question = createQuestion(subject, difficulty);
        questions.push(question);
    }
    return questions;
}

function createQuestion(subject, difficulty) {
    var num1, num2, question = { text: '', answers: [] };
    switch (difficulty) {
        case 'mudah':
            num1 = getRandomInt(1, 50);
            num2 = getRandomInt(1, 50);
            break;
        case 'sedang':
            num1 = getRandomInt(50, 100);
            num2 = getRandomInt(50, 100);
            break;
        case 'sulit':
            num1 = getRandomInt(100, 300);
            num2 = getRandomInt(100, 300);
            break;
    }
    var isDecimal = Math.random() > 0.5;
    if (isDecimal) {
        num1 = parseFloat((num1 / 10).toFixed(1));
        num2 = parseFloat((num2 / 10).toFixed(1));
    }

    switch (subject) {
        case 'pertambahan':
            question.text = `Berapakah hasil dari ${num1} + ${num2}?`;
            question.answers = generateAnswers(num1 + num2, isDecimal);
            break;
        case 'pengurangan':
            question.text = `Berapakah hasil dari ${num1} - ${num2}?`;
            question.answers = generateAnswers(num1 - num2, isDecimal);
            break;
        case 'perkalian':
            question.text = `Berapakah hasil dari ${num1} x ${num2}?`;
            question.answers = generateAnswers(num1 * num2, isDecimal);
            break;
        case 'pembagian':
            num1 = parseFloat((num1 * num2).toFixed(1));
            question.text = `Berapakah hasil dari ${num1} / ${num2}?`;
            question.answers = generateAnswers(parseFloat((num1 / num2).toFixed(1)), true);
            break;
    }
    return question;
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateAnswers(correctAnswer, isDecimal) {
    var answers = [{ text: correctAnswer.toString(), correct: true }];
    while (answers.length < 4) {
        var wrongAnswer = correctAnswer + getRandomInt(-10, 10);
        if (isDecimal) {
            wrongAnswer = parseFloat((wrongAnswer / 10).toFixed(1));
        }
        if (wrongAnswer !== correctAnswer && !answers.find(a => a.text == wrongAnswer.toString())) {
            answers.push({ text: wrongAnswer.toString(), correct: false });
        }
    }
    return answers.sort(() => Math.random() - 0.5);
}

function displayQuestion(question) {
    document.getElementById('nextQuestionSound').play();
    document.getElementById('question-text').innerText = question.text;
    var answerButtons = document.getElementById('answer-buttons');
    answerButtons.innerHTML = '';
    question.answers.forEach(function (answer) {
        var button = document.createElement('button');
        button.innerText = answer.text;
        button.classList.add('main-button');
        button.onclick = function () {
            selectAnswer(this, answer.correct);
        };
        answerButtons.appendChild(button);
    });
}

function selectAnswer(button, correct) {
    var modal = document.getElementById("myModal");
    var modalMessage = document.getElementById("modal-message");
    var nextButton = document.getElementById("nextBtn");

    modalMessage.innerText = correct ? "Jawaban Anda benar!" : "Jawaban Anda salah.";
    nextButton.className = 'main-button ' + (correct ? 'correct-button' : 'incorrect-button');

    modal.style.display = "block";

    nextButton.onclick = function () {
        modal.style.display = "none";
        checkAnswer(correct);
        nextQuestion();
    };
}

function checkAnswer(correct) {
    if (correct) {
        score++;
    }
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion >= totalQuestions) {
        endQuiz();
    } else {
        displayQuestion(selectedQuestions[currentQuestion]);
    }
}

function showFinalScore() {
    document.getElementById('score-text').innerText = "Skor Anda: " + score + "/" + totalQuestions;
    showPage('score-page');
    score = 0;
    currentQuestion = 0;
}

function retryQuiz() {
    score = 0;
    currentQuestion = 0;
    showPage('landing-page');
}

showPage('landing-page');
